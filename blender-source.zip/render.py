"""Render transparent fallback images from the editable Blender models."""
import bpy
from mathutils import Vector
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

import sys

names = sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else ("key", "postcard", "film")
for name in names:
    bpy.ops.wm.open_mainfile(filepath=str(ROOT / "models" / f"{name}.blend"))
    scene = bpy.context.scene
    front = name != "film"
    position = (1,-1,5.7) if front else (1,-5.7,1.5)
    bpy.ops.object.camera_add(location=position)
    scene.camera = bpy.context.object
    scene.camera.rotation_euler = (-Vector(position)).to_track_quat("-Z", "Y").to_euler()
    scene.camera.data.type = "ORTHO"
    scene.camera.data.ortho_scale = 4.1
    for location, color, energy in [
        ((-2,-3,5), (1,.73,.46), 620),
        ((3,1,3), (.48,.55,1), 510),
        ((0,-5,1), (1,.85,.75), 300),
    ]:
        bpy.ops.object.light_add(type="AREA", location=location)
        light = bpy.context.object
        light.rotation_euler = (-Vector(location)).to_track_quat("-Z", "Y").to_euler()
        light.data.color = color
        light.data.energy = energy
        light.data.size = 4
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 12
    scene.cycles.use_denoising = True
    scene.render.resolution_x = 640
    scene.render.resolution_y = 520
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = True
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.filepath = str(ROOT / "docs" / "assets" / f"{name}.png")
    bpy.ops.render.render(write_still=True)
