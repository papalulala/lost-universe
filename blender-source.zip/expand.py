"""Build nine additional objects for the second drift collection."""
import bpy
import math
from build import ROOT, box, disk, material, ring

def objects(name, m):
    if name == "spoon":
        box("Handle",(-.38,0,0),(1.48,.17,.09),m,.065)
        obj = disk("Bowl",(.67,0,.025),.43,.105,m)
        obj.scale.x = 1.25
    elif name == "button":
        ring("Raised rim",(0,0,0),.66,.095,m)
        disk("Button face",(0,0,-.045),.66,.12,m)
        for x in [-.19,.19]:
            for y in [-.19,.19]:
                ring("Thread hole",(x,y,.033),.08,.026,m)
    elif name == "ticket":
        box("Ticket",(0,0,0),(2.25,.92,.055),m,.07)
        for y in [-.29,-.1,.1,.29]:
            box("Perforation",(.58,y,.029),(.045,.08,.014),m)
        for y in [-.2,.06,.25]:
            box("Printed line",(-.32,y,.032),(.92,.045,.014),m)
    elif name == "comb":
        box("Comb spine",(0,.26,0),(2.18,.28,.13),m,.05)
        for i in range(12):
            if i != 4:
                box("Tooth",(-.98+i*.178,-.13,0),(.082,.6,.10),m,.025)
    elif name == "notebook":
        box("Cover",(0,0,0),(1.55,1.95,.18),m,.055)
        box("Page block",(.04,0,-.09),(1.43,1.84,.11),m)
        box("Nameplate",(.12,.27,.095),(.79,.42,.025),m,.02)
        box("Bookmark",(.31,-.98,.015),(.18,.46,.035),m)
    elif name == "umbrella":
        shaft = box("Folded canopy",(0,0,0),(1.65,.23,.19),m,.07)
        shaft.rotation_euler.z = -.22
        box("Tie",(.14,-.031,.012),(.18,.3,.22),m,.025)
        ring("Handle",(-.99,.27,0),.23,.055,m)
        box("Tip",(.91,-.21,0),(.29,.085,.085),m,.025)
    elif name == "tape":
        box("Cassette shell",(0,0,0),(2.1,1.3,.19),m,.055)
        box("Label",(0,.22,.10),(1.86,.49,.02),m)
        for x in [-.48,.48]:
            ring("Spool",(x,.06,.121),.18,.04,m)
        box("Tape gate",(0,-.49,.1),(1.12,.22,.05),m,.025)
    elif name == "stamp":
        box("Stamp block",(0,0,0),(1.36,.94,.32),m,.05)
        box("Rubber face",(0,0,.185),(1.21,.80,.09),m,.035)
        for x in [-.35,0,.35]:
            box("Cut mark",(x,0,.24),(.07,.51,.04),m,.012)
    elif name == "eraser":
        box("Eraser",(0,0,0),(1.64,.80,.32),m,.13)
        sleeve = box("Paper sleeve",(.27,0,0),(.71,.85,.35),m,.05)
        sleeve.rotation_euler.z = -.07

for name in ("spoon","button","ticket","comb","notebook","umbrella","tape","stamp","eraser"):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version = 0
    objects(name,material("Paper white",(.88,.88,.88)))
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/"models"/f"{name}.blend"))
    bpy.ops.export_scene.gltf(filepath=str(ROOT/"docs"/"assets"/f"{name}.glb"),export_format="GLB")
