"""Run with Blender 4.1 in background mode."""
import bpy
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def material(name, color, metal=0, roughness=.42):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (*color, 1)
    shader.inputs["Metallic"].default_value = metal
    shader.inputs["Roughness"].default_value = roughness
    return mat

def finish(obj, name, mat, bevel=0):
    obj.name = name
    obj.data.materials.append(mat)
    if bevel:
        mod = obj.modifiers.new("Worn edges", "BEVEL")
        mod.width = bevel
        mod.segments = 3
        obj.modifiers.new("Weighted normals", "WEIGHTED_NORMAL")
    return obj

def box(name, loc, size, mat, bevel=.01):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    obj = bpy.context.object
    obj.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return finish(obj, name, mat, bevel)

def ring(name, loc, radius, thickness, mat):
    bpy.ops.mesh.primitive_torus_add(location=loc, major_radius=radius, minor_radius=thickness)
    obj = finish(bpy.context.object, name, mat)
    for face in obj.data.polygons:
        face.use_smooth = True
    return obj

def key():
    brass = material("Patinated brass", (.47,.29,.09), .72)
    tape = material("Blue cloth tape", (.035,.22,.8), 0,.69)
    scratch = material("Oxidized scratches", (.15,.085,.03), .55)
    ring("Bow", (-.82,0,0), .44,.13,brass)
    box("Key blade", (.38,0,0), (1.65,.31,.14),brass,.04)
    for x, depth in [( .4,.43),(.68,.3),(.96,.48),(1.13,.37)]:
        box("Cut tooth",(x,-depth/2,0),(.15,depth,.13),brass)
    for y in [-.05,.05]:
        box("Keyway groove",(.62,y,.072),(.97,.018,.008),scratch,.002)
    for i in range(4):
        wrap = box("Tape overlap",(-.45+i*.105,0,.006),(.145,.45-i*.025,.23),tape,.032)
        wrap.rotation_euler.z = -.16+i*.035

def postcard():
    paper = material("Old paper",(.77,.58,.33))
    ink = material("Indigo ink",(.06,.12,.21))
    sky = material("Dusk print",(.65,.25,.11))
    sun = material("Faded sun",(.95,.64,.22))
    box("Postcard",(0,0,0),(2.42,1.55,.055),paper,.025)
    box("Printed sky",(0,0,.03),(2.23,1.36,.012),sky)
    disk("Sun",(.47,.27,.041),.25,.012,sun)
    for i,w in enumerate([2.22,1.9,1.5,1.15]):
        obj=box("Horizon",(-.1*i,-.48+i*.11,.045),(w,.22,.012),ink,.03)
        obj.rotation_euler.z = .025*i
    for y in [-.29,-.11,.07]:
        box("Address line",(.57,y,-.032),(.79,.012,.009),ink,.002)
    box("Stamp",(.88,.48,-.032),(.27,.31,.012),sky)
    box("Divider",(0,0,-.032),(.012,1.12,.009),ink,.002)

def disk(name, loc, radius, depth, mat):
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=radius, depth=depth, location=loc)
    return finish(bpy.context.object,name,mat,.015)

def film():
    black = material("Dark plastic",(.028,.034,.04),.18)
    silver = material("Aluminum",(.52,.55,.55),.7)
    amber = material("Ochre label",(.85,.48,.075))
    strip = material("Developed film",(.12,.045,.025),.15)
    disk("Canister",(-.49,0,0),.49,1.38,amber)
    for z in [-.71,.71]:
        disk("End cap",(-.49,0,z),.51,.12,silver)
    disk("Spool",(-.49,0,.81),.17,.17,black)
    box("Film gate",(-.03,0,0),(.18,.21,1.35),black,.045)
    for i in range(12):
        x = .06+i*.112
        y = .05+.19*math.sin(i*.26)
        panel = box("Film segment",(x,y,0),(.12,.03,.73),strip,.004)
        panel.rotation_euler.z = .4*math.cos(i*.26)
        for z in [-.29,.29]:
            box("Sprocket mark",(x,y-.017,z),(.046,.009,.08),amber,.003)

for name, build in [("key",key),("postcard",postcard),("film",film)]:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version = 0
    build()
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/"models"/f"{name}.blend"))
    bpy.ops.export_scene.gltf(filepath=str(ROOT/"docs"/"assets"/f"{name}.glb"),export_format="GLB")
