"""Rebuild the three objects used in the first branching route."""
import bpy
import math
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from build import ROOT, box, disk, finish, material, ring

def mesh(name, vertices, faces, mat, smooth=False):
    data = bpy.data.meshes.new(name)
    data.from_pydata(vertices, [], faces)
    data.update()
    obj = bpy.data.objects.new(name,data)
    bpy.context.collection.objects.link(obj)
    finish(obj,name,mat)
    for face in data.polygons:
        face.use_smooth = smooth
    return obj

def solid(name, points, depth, mat, bevel):
    n = len(points)
    vertices = [(x,y,z) for z in (-depth/2,depth/2) for x,y in points]
    faces = [tuple(reversed(range(n))),tuple(range(n,2*n))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    obj = mesh(name,vertices,faces,mat)
    mod = obj.modifiers.new("Softened edge","BEVEL")
    mod.width = bevel
    mod.segments = 3
    obj.modifiers.new("Weighted normals","WEIGHTED_NORMAL")
    return obj

def key(mat):
    pts = [(-.45,.19),(-.58,.32),(-.83,.39),(-1.06,.34),(-1.19,.19),(-1.24,-.08),(-1.12,-.29),(-.89,-.39),(-.64,-.35),(-.47,-.24),(-.32,-.24),(-.25,-.17),(-.04,-.17),(.06,-.24),(.15,-.24),(.22,-.12),(.32,-.12),(.42,-.26),(.5,-.26),(.61,-.15),(.68,-.15),(.78,-.22),(.85,-.22),(.93,-.13),(1.05,-.13),(1.24,.01),(1.13,.15),(-.28,.15),(-.32,.2)]
    blank = solid("Stamped brass silhouette",pts,.115,mat,.016)
    bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.145,depth=1,location=(-.94,.025,0))
    cutter = bpy.context.object
    bpy.context.view_layer.objects.active = blank
    boolean = blank.modifiers.new("Keyring hole","BOOLEAN")
    boolean.object = cutter
    bpy.ops.object.modifier_move_up(modifier=boolean.name)
    bpy.ops.object.modifier_move_up(modifier=boolean.name)
    bpy.ops.object.modifier_apply(modifier=boolean.name)
    bpy.data.objects.remove(cutter,do_unlink=True)
    for y,w in [(0.064,1.12),(-.036,1.04)]:
        box("Blade milling line",(.51,y,.058),(w,.018,.008),mat,.004)
    for x,angle in [(-.55,-.16),(-.43,-.14),(-.32,-.11)]:
        wrap=box("Overlapping cloth tape",(x,-.015,.014),(.17,.45,.142),mat,.029)
        wrap.rotation_euler.z=angle
    tab=box("Lifted tape corner",(-.28,.173,.104),(.11,.12,.018),mat,.007)
    tab.rotation_euler.x=.43

def spoon(mat):
    count=64
    vertices=[(.67,0,-.11)]
    for radius in (.15,.3,.48,.65,.82,1):
        for i in range(count):
            a=i*math.tau/count
            vertices.append((.67+.59*radius*math.cos(a),.43*radius*math.sin(a),-.11+.24*radius**2))
    faces=[(0,1+i,1+(i+1)%count) for i in range(count)]
    for row in range(5):
        a=1+row*count
        b=a+count
        faces += [(a+i,b+i,b+(i+1)%count,a+(i+1)%count) for i in range(count)]
    bowl=mesh("Pressed concave bowl",vertices,faces,mat,True)
    bowl.modifiers.new("Rolled metal thickness","SOLIDIFY").thickness=.035
    curve=bpy.data.curves.new("Bowl rim contour","CURVE")
    curve.dimensions="3D"
    curve.bevel_depth=.0037
    curve.bevel_resolution=2
    spline=curve.splines.new("POLY")
    spline.points.add(23)
    for i,point in enumerate(spline.points):
        angle=-1.2+2.45*i/23
        r=.79+.09*math.sin(math.pi*i/23)
        point.co=(.67+.59*r*math.cos(angle),.43*r*math.sin(angle),-.11+.24*r*r+.006,1)
    mark=bpy.data.objects.new("Ink contour inside bowl",curve)
    bpy.context.collection.objects.link(mark)
    curve.materials.append(mat)
    handle=solid("Tapered handle",[(-1.48,-.03),(-1.46,-.1),(-1.37,-.15),(-1.14,-.148),(-.68,-.094),(-.28,-.051),(.18,-.043),(.24,0),(.18,.043),(-.28,.051),(-.68,.094),(-1.14,.148),(-1.37,.15),(-1.46,.1),(-1.48,.03)],.07,mat,.027)
    handle.location.z=.1

def film(mat):
    disk("Crimped metal cartridge",(-.52,0,0),.465,1.29,mat)
    for z in [-.65,.65]:
        disk("Rolled end seam",(-.52,0,z),.487,.081,mat)
        ring("Stamped end rim",(-.52,0,z+math.copysign(.041,z)),.41,.019,mat)
    disk("Recessed spool hub",(-.52,0,.739),.172,.14,mat)
    box("Spool notch",(-.52,-.148,.771),(.12,.072,.075),mat,.012)
    box("Light-trap lip",(-.11,-.17,0),(.21,.16,1.16),mat,.049)
    # One bent strip. Omitted cells form actual holes along both edges.
    rows=(-.49,-.44,-.36,.36,.44,.49)
    length=26
    vertices=[]
    for i in range(length+1):
        t=i/length
        for z in rows:
            taper=.64+.36*(1-min(1,max(0,(t-.72)/.28)))
            vertices.append((-.07+1.58*t,-.25+.31*math.sin(t*2.7),z*taper))
    faces=[]
    for i in range(length):
        for j in range(5):
            if j in (1,3) and i%2==1:
                continue
            k=i*6+j
            faces.append((k,k+1,k+7,k+6))
    strip=mesh("Curled perforated film leader",vertices,faces,mat,True)
    strip.modifiers.new("Film thickness","SOLIDIFY").thickness=.011

def comb(mat):
    edge=[(-1.24,-.04)]
    for i in range(15):
        x=-1.18+i*.162
        if i==4:
            edge.extend([(x,-.045),(x+.04,-.12),(x+.085,-.075),(x+.118,-.045)])
            continue
        tip=-.61+.125*(x/1.2)**2
        edge.extend([(x,-.045),(x+.023,tip+.035),(x+.047,tip),
                     (x+.067,tip+.024),(x+.114,-.045)])
    edge.extend([(1.22,-.035),(1.25,.04),(1.22,.18),(1.14,.23),(.55,.28),
                 (-.4,.29),(-1.05,.25),(-1.21,.19),(-1.26,.08)])
    solid("Rounded pocket comb with broken fifth tooth",edge,.115,mat,.021)

def button(mat):
    profile=[(.001,-.095),(.54,-.095),(.66,-.078),(.704,-.042),
             (.712,.016),(.686,.084),(.632,.115),(.581,.113),(.51,.074),
             (.43,.038),(.29,.026),(.001,.025)]
    n=96
    vertices=[(r*math.cos(i*math.tau/n),r*math.sin(i*math.tau/n),z)
              for r,z in profile for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces.extend([tuple(reversed(range(n))),tuple(range((len(profile)-1)*n,len(profile)*n))])
    obj=mesh("Recessed four-hole button",vertices,faces,mat,True)
    for x in (-.154,.154):
        for y in (-.154,.154):
            bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.078,depth=.6,location=(x,y,0))
            cutter=bpy.context.object
            bpy.context.view_layer.objects.active=obj
            mod=obj.modifiers.new("Thread bore","BOOLEAN")
            mod.object=cutter
            bpy.ops.object.modifier_apply(modifier=mod.name)
            bpy.data.objects.remove(cutter,do_unlink=True)
    bevel=obj.modifiers.new("Soft bore rims","BEVEL")
    bevel.width=.008
    bevel.segments=2

def postcard(mat):
    def z(x,y):
        fold=max(0,(x+y-1.34)/.49)
        return .018*x*x-.026*y*y+.21*fold*fold
    nx,ny=26,16
    vertices=[(x,y,z(x,y)) for j in range(ny+1) for i in range(nx+1)
              for x,y in [(-1.2+2.4*i/nx,-.74+1.48*j/ny)]]
    faces=[(k,k+1,k+nx+2,k+nx+1) for j in range(ny) for i in range(nx)
           for k in [j*(nx+1)+i]]
    card=mesh("Warped postcard paper with lifted corner",vertices,faces,mat,True)
    card.modifiers.new("Paper edge","SOLIDIFY").thickness=.025
    ink=material("Graphite print",(.22,.23,.21))
    def stroke(name, points, side=1):
        curve=bpy.data.curves.new(name,"CURVE")
        curve.dimensions="3D"
        curve.bevel_depth=.004
        curve.bevel_resolution=2
        spline=curve.splines.new("POLY")
        spline.points.add(len(points)-1)
        for point,(x,y) in zip(spline.points,points):
            point.co=(x,y,z(x,y)+(.005 if side==1 else -.031),1)
        obj=bpy.data.objects.new("Ink contour "+name,curve)
        bpy.context.collection.objects.link(obj)
        curve.materials.append(ink)
    stroke("coastal ridge",[(-1.02,-.18),(-.78,-.12),(-.59,.04),(-.48,-.015),(-.31,.15),(-.12,.075),(.04,-.14),(.31,-.24),(.53,-.22),(1.02,-.14)])
    for j in range(3):
        y=-.32-j*.095
        stroke("water line",[(-.89+j*.27,y),(-.52+j*.24,y+.024),(-.22+j*.28,y-.008),(.23+j*.17,y+.014)])
    stroke("sun",[(.49+.143*math.cos(i*math.tau/48),.28+.143*math.sin(i*math.tau/48)) for i in range(49)])
    for y in (-.23,-.06,.11):
        stroke("address line",[(-.96,y),(-.28,y)],-1)
    stroke("address separator",[(.02,-.49),(.02,.49)],-1)

def tube(name, points, radius, mat):
    curve=bpy.data.curves.new(name,"CURVE")
    curve.dimensions="3D"
    curve.bevel_depth=radius
    curve.bevel_resolution=2
    spline=curve.splines.new("POLY")
    spline.points.add(len(points)-1)
    for point,coords in zip(spline.points,points):
        point.co=(*coords,1)
    obj=bpy.data.objects.new(name,curve)
    bpy.context.collection.objects.link(obj)
    curve.materials.append(mat)
    return obj

def cut(obj,cutter):
    bpy.context.view_layer.objects.active=obj
    mod=obj.modifiers.new("Recess","BOOLEAN")
    mod.object=cutter
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter,do_unlink=True)

def ticket(mat):
    card=solid("Thin card ticket",[(-1.14,-.43),(1.13,-.43),(1.15,-.40),(1.15,.42),
                                  (1.11,.445),(-1.13,.44),(-1.16,.39),(-1.16,-.39)],.032,mat,.008)
    for x,y,length in [(-.92,.27,.93),(-.92,.06,1.28),(-.92,-.13,.64),(-.92,-.28,1.18)]:
        tube("Ink contour printed rule",[(x,y,.018),(x+length,y,.018)],.005,mat)
    for y in [-.33,-.23,-.13,-.03,.07,.17,.27,.37]:
        tube("Ink contour printed divider",[(.61,y,.018),(.61,y+.034,.018)],.004,mat)
    return card

def notebook(mat):
    cover=[(-.79,-1.0),(.7,-1.0),(.77,-.93),(.77,.95),(.71,1.0),(-.76,1.0),(-.86,.92),(-.86,-.92)]
    for z in (-.16,.16):
        solid("Rounded cloth cover",cover,.055,mat,.023).location.z=z
    box("Bound paper block",(-.01,0,0),(1.44,1.89,.28),mat,.064)
    box("Rounded book spine",(-.792,0,0),(.165,1.93,.365),mat,.071)
    for z in [-.087,-.038,.011,.06,.108]:
        tube("Ink contour page edges",[(.707,-.88,z),(.716,0,z+.006),(.708,.88,z)],.003,mat)
    pts=[(.22,-.65,.055),(.35,-.65,.055),(.35,-.96,.047),(.36,-1.08,.03),
         (.37,-1.21,-.015),(.34,-1.34,-.09),(.24,-1.32,-.09),(.25,-1.20,-.014),
         (.24,-1.08,.028),(.22,-.96,.046)]
    ribbon=mesh("Curving ribbon bookmark",pts,[tuple(reversed(range(len(pts))))],mat)
    ribbon.modifiers.new("Ribbon thickness","SOLIDIFY").thickness=.012

def umbrella(mat):
    n=48
    profile=[(-.91,.105),(-.72,.20),(-.4,.175),(-.07,.139),(.2,.154),(.62,.105),(.93,.033)]
    vertices=[]
    for j,(x,r) in enumerate(profile):
        for i in range(n):
            a=i*math.tau/n
            wave=r*(1+.18*math.cos(6*a+j*.30))
            vertices.append((x,wave*math.cos(a),wave*math.sin(a)))
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces += [tuple(reversed(range(n))),tuple(range((len(profile)-1)*n,len(profile)*n))]
    mesh("Pleated folded umbrella canopy",vertices,faces,mat,True)
    for i in (0,16,32):
        tube("Ink contour folded seam",[vertices[j*n+(i+j//2)%n] for j in range(len(profile))],.006,mat)
    tube("Hook handle",[(-.88,0,0),(-1.12,0,0)]+[(-1.12+.16*math.cos(a),.16+.16*math.sin(a),0)
         for a in [-math.pi/2-i*.16 for i in range(25)]],.059,mat)
    tube("Metal tip",[(.88,0,0),(1.15,0,0)],.029,mat)
    strap=mesh("Loose retaining strap",[(-.24,-.15,.05),(-.09,-.15,.05),(-.04,-.21,.13),
               (.11,-.3,.205),(-.01,-.34,.218),(-.19,-.215,.13)],[(0,1,2,3,4,5)],mat)
    strap.modifiers.new("Strap cloth","SOLIDIFY").thickness=.016

def tape(mat):
    shell=box("Cassette shell",(0,0,0),(2.16,1.38,.205),mat,.055)
    for x in (-.48,.48):
        cut(shell,disk("Spool bore cutter",(x,.10,0),.172,.65,mat))
        ring("Recessed hub",(x,.1,.015),.118,.024,mat)
        for i in range(6):
            a=i*math.tau/6
            ring_tooth=box("Hub tooth",(x+.108*math.cos(a),.1+.108*math.sin(a),.015),(.039,.025,.07),mat,.006)
            ring_tooth.rotation_euler.z=a
    cut(shell,box("Tape gate cutter",(0,-.56,.01),(1.23,.31,.19),mat,.035))
    tube("Ink contour seam",[(-1.03,-.67,0),(1.03,-.67,0),(1.08,-.61,0),(1.08,.62,0),
         (1.02,.69,0),(-1.02,.69,0),(-1.08,.62,0),(-1.08,-.61,0),(-1.03,-.67,0)],.005,mat)
    for x in (-.94,.94):
        for y in (-.52,.54):
            ring("Shell screw rim",(x,y,.102),.033,.008,mat)
    for y in (.44,.52):
        tube("Ink contour label line",[(-.75,y,.104),(.67,y,.104)],.004,mat)

def stamp(mat):
    shape=[(-.76,-.42),(.71,-.42),(.77,-.36),(.77,.36),(.71,.42),(-.7,.42),(-.76,.35)]
    solid("Wooden block",shape,.27,mat,.054)
    box("Wooden grip",(-.02,0,-.19),(1.28,.66,.18),mat,.079)
    face=box("Rubber printing face",(0,0,.181),(1.36,.71,.13),mat,.032)
    for x,angle in [(-.32,0),(-.045,.13),(.23,-.45)]:
        cutter=box("Carving cutter",(x,.015,.245),(.042,.48,.105),mat,.008)
        cutter.rotation_euler.z=angle
        cut(face,cutter)

def eraser(mat):
    solid("Worn rubber body",[(-.91,-.25),(-.78,-.36),(.75,-.37),(.85,-.31),(.86,.30),
                             (.79,.36),(-.75,.36),(-.87,.26),(-.93,.08)],.31,mat,.082)
    cross=[(-.373,.11),(-.34,.164),(.33,.164),(.374,.112),(.374,-.11),
           (.33,-.164),(-.33,-.164),(-.373,-.11)]
    vertices=[(x,y,z) for x in (-.09,.59) for y,z in cross]
    faces=[(i,(i+1)%8,(i+1)%8+8,i+8) for i in range(8)]
    sleeve=mesh("Thin folded paper sleeve",vertices,faces,mat)
    sleeve.modifiers.new("Paper thickness","SOLIDIFY").thickness=.012
    flap=mesh("Lifted sleeve corner",[(-.09,.20,.165),(.075,.35,.166),(-.19,.385,.231),(-.24,.27,.198)],[(0,1,2,3)],mat)
    flap.modifiers.new("Flap thickness","SOLIDIFY").thickness=.012
    for x in (.17,.24):
        tube("Ink contour sleeve print",[(x,-.30,.172),(x,.29,.172)],.004,mat)

def mirror(mat):
    frame=disk("Oval metal frame",(0,.35,0),.62,.13,mat)
    frame.scale.y=1.22
    glass=disk("Recessed mirror glass",(0,.35,.071),.53,.025,mat)
    glass.scale.y=1.22
    tube("Rolled bezel",[(.582*math.cos(i*math.tau/64),.35+.706*math.sin(i*math.tau/64),.069)
                         for i in range(65)],.027,mat)
    solid("Tapered mirror handle",[(-.18,-1.03),(-.13,-1.14),(0,-1.19),(.13,-1.14),(.18,-1.03),
          (.13,-.68),(.085,-.33),(-.085,-.33),(-.13,-.68)],.112,mat,.03)
    tube("Ink contour worn glass edge",[(.28,-.11,.087),(.32,-.085,.087),(.29,-.025,.087)],.004,mat)

def bookmark(mat):
    outline=[(-.31,-1.13,.02),(.31,-1.14,.023),(.32,-.1,-.041),(.315,.08,-.027),
             (.29,1.13,.112),(-.315,1.11,.10),(-.33,.08,-.025),(-.32,-.1,-.039)]
    paper=mesh("Folded bookmark paper",outline,[(0,1,2,7),(7,2,3,6),(6,3,4,5)],mat)
    paper.modifiers.new("Thin paper","SOLIDIFY").thickness=.021
    tube("Ink contour fold line",[outline[7],(.01,-.1,-.026),outline[2]],.004,mat)
    tube("Ink contour pencilled mark",[(-.08,.43,.037),(-.02,.51,.047),(.09,.46,.041)],.004,mat)

def envelope(mat):
    outline=[(-1.15,-.55),(-1.1,-.62),(1.10,-.61),(1.15,-.54),(1.13,.58),(-1.14,.59)]
    solid("Envelope front paper",outline,.025,mat,.008).location.z=-.028
    back=mesh("Folded envelope back",[(x,y,.023) for x,y in outline]+[(0,-.24,.034)],
              [(0,1,6,5),(1,2,3,6),(6,3,4),(5,6,4)],mat)
    back.modifiers.new("Paper thickness","SOLIDIFY").thickness=.016
    flap=mesh("Torn open flap",[(-1.13,.56,.014),(1.13,.56,.014),(.76,.75,.071),(.51,.85,.11),
              (.31,.9,.13),(.17,.86,.122),(.04,.95,.137),(-.21,.93,.133),(-.58,.81,.089)],
              [(0,1,2,3,4,5,6,7,8)],mat)
    flap.modifiers.new("Flap thickness","SOLIDIFY").thickness=.016
    tube("Ink contour envelope seam",[(-1.12,.49,.035),(0,-.24,.044),(1.11,.49,.035)],.005,mat)

def luggage(mat):
    shape=[(-1.13,-.44),(.80,-.44),(1.01,-.26),(1.01,.26),(.80,.44),(-1.13,.44)]
    body=solid("Leather luggage tag",shape,.12,mat,.045)
    cut(body,disk("Strap hole cutter",(.84,0,0),.078,.48,mat))
    box("Recessed luggage label",(-.31,0,.067),(1.28,.55,.025),mat,.039)
    for y in (-.13,.02,.16):
        tube("Ink contour label rule",[(-.79,y,.082),(.22,y,.082)],.004,mat)
    for y in (-.36,.36):
        for i in range(12):
            x=-.99+i*.145
            tube("Ink contour leather stitch",[(x,y,.062),(x+.056,y,.062)],.004,mat)
    tube("Bent leather strap",[(.83,0,.017),(1.12,-.105,.063),(1.38,-.08,.093),
                              (1.49,.025,.071),(1.37,.12,.019),(1.12,.097,-.035),(.84,0,-.031)],.043,mat)

def earbuds(mat):
    def smooth(name, points, radius):
        curve=bpy.data.curves.new(name,"CURVE")
        curve.dimensions="3D"
        curve.bevel_depth=radius
        curve.bevel_resolution=3
        spline=curve.splines.new("BEZIER")
        spline.bezier_points.add(len(points)-1)
        for point,coords in zip(spline.bezier_points,points):
            point.co=coords
            point.handle_left_type=point.handle_right_type="AUTO"
        obj=bpy.data.objects.new(name,curve)
        bpy.context.collection.objects.link(obj)
        curve.materials.append(mat)
    for i,(x,y) in enumerate([(-.65,.66),(.59,.51)]):
        shell=disk("Earbud housing left" if i==0 else "Earbud housing right",(x,y,.045),.187,.145,mat)
        shell.scale.x=1.11
        ring("Speaker grille rim",(x,y,.122),.119,.014,mat)
        for j in range(5):
            d=-.06+j*.03
            tube("Ink contour grille slot",[(x-.055,y+d,.13),(x+.055,y+d,.13)],.003,mat)
        smooth("Earbud branch lead",[(x,y-.12,0),(x*.83,.19,.015),(x*.53,-.07,.025),(.03,-.32,0)],.017)
    box("Cable junction",(.03,-.32,0),(.105,.17,.086),mat,.039)
    smooth("Loosely looped lead",[(.03,-.36,0),(-.21,-.60,0),(-.62,-.65,0),(-.83,-.43,-.04),
           (-.55,-.22,-.05),(.09,-.59,-.065),(.53,-.8,-.052),(.89,-.68,0)],.019)
    box("Plug grip",(.89,-.60,0),(.13,.23,.105),mat,.033)
    tube("Metal audio jack",[(.89,-.54,0),(.89,-.27,0)],.031,mat)
    for y in (-.38,-.33):
        tube("Ink contour jack divider",[(.86,y,.025),(.92,y,.025)],.004,mat)

def pencil(mat):
    n=6
    profile=[(-1.05,.164),(.51,.164),(.76,.097),(.96,.033),(1.085,.013)]
    vertices=[(x,r*math.cos(math.tau*i/n),r*math.sin(math.tau*i/n))
              for x,r in profile for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces += [tuple(reversed(range(n))),tuple(range((len(profile)-1)*n,len(profile)*n))]
    mesh("Short hexagonal pencil barrel",vertices,faces,mat)
    tube("Ink contour chipped lacquer",[(-.35,-.079,.142),(-.23,-.088,.141),
         (-.17,-.06,.143),(-.02,-.073,.143)],.006,mat)
    tube("Ink contour graphite tip",[(.956,0,.029),(1.028,0,.022),(1.083,0,.012)],.004,mat)

def thimble(mat):
    n=64
    profile=[(.57,-.65),(.57,-.52),(.54,-.42),(.49,.28),(.42,.52),(.29,.63),(.001,.67)]
    vertices=[(r*math.cos(i*math.tau/n),r*math.sin(i*math.tau/n),z)
              for r,z in profile for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces.append(tuple(range((len(profile)-1)*n,len(profile)*n)))
    shell=mesh("Hollow tapered thimble",vertices,faces,mat,True)
    shell.modifiers.new("Stamped silver wall","SOLIDIFY").thickness=.038
    ring("Rolled thimble lip",(0,0,-.62),.554,.027,mat)
    for row in range(5):
        z=-.32+row*.14
        r=.534-(z+.32)*.074
        for i in range(15):
            angle=(i+row*.5)*math.tau/15
            tube("Ink contour shallow dimple",[(r*math.cos(angle+d),r*math.sin(angle+d),z+h)
                 for d,h in [(-.032,.016),(0,-.014),(.032,.016)]],.004,mat)

def watch(mat):
    for side in (-1,1):
        end=side*1.12
        strap=solid("Curved leather watch strap",[(-.23,side*.36),(.23,side*.36),
                    (.19,end),(.10,end+side*.09),(-.11,end+side*.08),(-.18,end)],.083,mat,.021)
        if side<0:
            for i in range(4):
                y=-.65-i*.12
                cut(strap,disk("Buckle hole cutter",(0,y,0),.034,.35,mat))
    disk("Watch case",(0,0,0),.49,.19,mat)
    disk("Stopped watch dial",(0,0,.105),.415,.035,mat)
    ring("Watch bezel",(0,0,.102),.449,.033,mat)
    box("Winding crown",(.495,0,.005),(.14,.126,.125),mat,.035)
    for i in range(12):
        a=i*math.tau/12
        tube("Ink contour dial mark",[(.34*math.cos(a),.34*math.sin(a),.128),
             (.38*math.cos(a),.38*math.sin(a),.128)],.005,mat)
    for angle,length in [(-1.72,.21),(-.315,.30)]:
        tube("Ink contour stopped hand",[(0,0,.133),(length*math.cos(angle),length*math.sin(angle),.133)],.011,mat)

def matchbox(mat):
    sleeve=box("Printed matchbox sleeve",(-.27,0,0),(1.57,.88,.44),mat,.032)
    cut(sleeve,box("Drawer recess cutter",(-.27,0,0),(2,.746,.34),mat,.013))
    box("Sliding tray bottom",(.37,0,-.155),(1.54,.70,.045),mat,.022)
    for y in (-.335,.335):
        box("Thin folded tray wall",(.36,y,-.032),(1.53,.042,.24),mat,.014)
    box("Exposed tray end",(1.12,0,-.032),(.045,.702,.24),mat,.013)
    for i,(y,tip) in enumerate([(-.19,.92),(-.045,1.02),(.137,.87)]):
        tube("Wooden match splint",[(.16,y,-.08),(tip-.08,y+.02,-.076)],.025,mat)
        tip_obj=disk("Rounded match head",(tip-.066,y+.02,-.076),.046,.061,mat)
        tip_obj.scale.x=1.37
    for y in (-.27,-.19,.17,.25):
        tube("Ink contour label ornament",[(-.88,y,.223),(.29,y,.223)],.004,mat)

def glasses(mat):
    for x,side in [(-.64,-1),(.64,1)]:
        lens=disk("Round spectacle lens",(x,0,0),.49,.032,mat)
        lens.scale.y=.91
        tube("Wire spectacle rim",[(x+.50*math.cos(i*math.tau/72),.455*math.sin(i*math.tau/72),.014)
              for i in range(73)],.022,mat)
        tube("Folded spectacle arm",[(x+side*.48,.14,-.012),(x+side*.54,.13,-.10),
             (x+side*.38,.075,-.172),(x-side*.22,-.12,-.199),(x-side*.44,-.24,-.218)],.024,mat)
        tube("Ink contour lens wipe",[(x-.23,.20,.019),(x-.11,.25,.019),(x+.03,.27,.019)],.004,mat)
    tube("Arched nose bridge",[(-.15,.105,.022),(-.10,.172,.042),(0,.211,.052),
         (.10,.172,.042),(.15,.105,.022)],.025,mat)

def mitten(mat):
    shape=[(-.36,-.68),(.32,-.68),(.40,-.38),(.43,.24),(.37,.68),(.23,.94),
           (.01,1.04),(-.22,.98),(-.38,.76),(-.45,.43),(-.49,.28),(-.66,.46),
           (-.81,.40),(-.84,.25),(-.76,.04),(-.54,-.19),(-.42,-.40)]
    solid("Rounded knitted mitten palm",shape,.27,mat,.105)
    cuff=box("Rib knit cuff",(-.015,-.73,0),(.74,.36,.275),mat,.072)
    for i in range(9):
        x=-.28+i*.067
        tube("Ink contour cuff rib",[(x,-.857,.141),(x,-.60,.144)],.005,mat)
    tube("Ink contour mended mitten seam",[(-.41,-.19,.14),(-.38,.025,.14),
         (-.41,.21,.14),(-.45,.29,.141)],.005,mat)

def bell(mat):
    n=64
    profile=[(.66,-.19),(.68,-.115),(.65,.03),(.55,.22),(.40,.365),(.24,.45),(.001,.475)]
    verts=[(r*math.cos(i*math.tau/n),r*math.sin(i*math.tau/n),z)
           for r,z in profile for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces.append(tuple(range((len(profile)-1)*n,len(profile)*n)))
    dome=mesh("Rounded bicycle bell dome",verts,faces,mat,True)
    dome.modifiers.new("Bell metal thickness","SOLIDIFY").thickness=.035
    ring("Rolled bell rim",(0,0,-.166),.652,.025,mat)
    clamp=ring("Handlebar clamp",(0,0,-.45),.245,.052,mat)
    clamp.rotation_euler.x=math.pi/2
    tube("Spring lever arm",[(.53,-.19,-.13),(.72,-.27,-.18),(.93,-.38,-.19)],.045,mat)
    box("Thumb striker tab",(.95,-.39,-.185),(.245,.184,.093),mat,.039)
    tube("Ink contour scuffed dome",[(.27,.22,.386),(.29,.17,.4),(.32,.125,.402)],.005,mat)

def spool(mat):
    for z in (-.65,.65):
        rim=disk("Turned wooden spool flange",(0,0,z),.63,.17,mat)
        cut(rim,disk("Axle hole cutter",(0,0,z),.13,.5,mat))
        ring("Rounded flange rim",(0,0,z),.59,.029,mat)
    wind=disk("Wound cotton thread",(0,0,0),.467,1.16,mat)
    cut(wind,disk("Central bore cutter",(0,0,0),.13,1.4,mat))
    tube("Ink contour winding",[(.468*math.cos(i*.20),.468*math.sin(i*.20),-.55+i*.0035)
         for i in range(315)],.004,mat)
    tube("Loose thread tail",[(.465,.02,.17),(.59,.08,.15),(.74,.17,.08),
         (.89,.13,.005),(1.02,.03,-.04)],.012,mat)

def whistle(mat):
    body=solid("Rounded whistle body",[(-1.14,-.21),(-.38,-.21),(-.26,-.36),(.49,-.41),
        (.76,-.28),(.87,-.05),(.85,.19),(.67,.35),(.41,.41),(-.22,.40),
        (-.38,.20),(-1.14,.20)],.33,mat,.067)
    cut(body,box("Air window cutter",(-.27,0,.167),(.35,.28,.17),mat,.025))
    cut(body,box("Mouth opening cutter",(-1.13,0,0),(.22,.24,.117),mat,.018))
    ring("Whistle lanyard ring",(.91,0,0),.155,.035,mat)
    tube("Ink contour whistle joint",[(-.88,-.17,.167),(-.43,-.17,.167),(-.34,-.24,.167)],.005,mat)

def coin(mat):
    n=72
    points=[((.68+.014*math.cos(i*.57)+.008*math.sin(i*.86))*math.cos(i*math.tau/n),
             (.68+.014*math.cos(i*.57)+.008*math.sin(i*.86))*math.sin(i*math.tau/n))
             for i in range(n)]
    solid("Worn coin face",points,.105,mat,.023)
    for z in (-.055,.055):
        tube("Ink contour worn rim",[(.589*math.cos(i*math.tau/64),.589*math.sin(i*math.tau/64),z)
             for i in range(65)],.007,mat)
    for a in [i*math.tau/36 for i in range(36) if i%7!=0]:
        tube("Ink contour worn reeding",[(.683*math.cos(a),.683*math.sin(a),z)
             for z in (-.032,.032)],.004,mat)
    tube("Ink contour rubbed emblem",[(-.22,-.18,.058),(-.11,.07,.058),(-.05,.27,.058),
         (.08,.13,.058),(.10,.01,.058),(.23,-.13,.058)],.007,mat)

def clothespin(mat):
    half=[(-1.14,.07),(-1.12,.25),(-.84,.27),(-.64,.21),(-.41,.21),
          (-.28,.30),(-.13,.26),(.07,.16),(.36,.19),(1.12,.34),
          (1.17,.18),(.36,.035),(.04,.035),(-.22,.055),(-.48,.10),(-.76,.045)]
    for side in (1,-1):
        solid("Upper wooden jaw" if side==1 else "Lower wooden jaw",
              [(x,y*side) for x,y in (half if side==1 else half[::-1])],.40,mat,.028)
        for y in (.11,.16):
            tube("Ink contour wood grain",[(-1.03,side*y,.201),(-.82,side*(y+.012),.202),
                 (-.70,side*(y+.015),.202)],.0038,mat)
    tube("Coiled steel spring",[(.03+.153*math.cos(i*.16),.153*math.sin(i*.16),-.2+i*.0033)
         for i in range(124)],.025,mat)
    tube("Caught cotton thread",[(-1.05,.035,-.17),(-1.08,.04,.12),
         (-1.15,.015,.21),(-1.28,-.09,.26),(-1.41,-.13,.22)],.012,mat)

def pencap(mat):
    cap=disk("Fountain pen cap barrel",(0,0,0),.245,1.99,mat)
    cut(cap,disk("Hollow cap cutter",(0,0,-.57),.204,1.28,mat))
    disk("Rounded finial",(0,0,1.002),.23,.095,mat)
    ring("Cap lip band",(0,0,-.904),.248,.016,mat)
    tube("Pocket clip",[(0,-.20,.94),(0,-.295,.875),(0,-.312,.71),
         (0,-.304,.35),(0,-.267,.11)],.039,mat)

def safetypin(mat):
    tube("Coiled safety pin wire",[(.66+.177*math.cos(-math.pi/2+i*math.tau/80),
         .177*math.sin(-math.pi/2+i*math.tau/80),i*.00072) for i in range(113)],.036,mat)
    tube("Safety pin back",[(-.78,-.164,0),(-.56,-.19,0),(.30,-.19,0),(.66,-.177,0)],.036,mat)
    tube("Safety pin needle",[(.755,.15,.078),(.59,.198,.078),(.28,.188,.064),
         (-.29,.131,.047),(-.81,.09,.039)],.029,mat)
    guard=solid("Folded safety pin clasp",[(-.99,-.16),(-.88,-.225),(-.68,-.216),
                (-.56,-.146),(-.58,.145),(-.71,.21),(-.93,.165)],.18,mat,.037)
    cut(guard,box("Clasp slot cutter",(-.72,.105,.035),(.25,.078,.095),mat,.017))

def shoehorn(mat):
    rows=[(-1.16,.30,.14),(-1.09,.43,.08),(-.87,.48,.014),(-.61,.43,0),
          (-.32,.31,.015),(0,.22,.055),(.38,.18,.10),(.72,.17,.17),(.96,.20,.28),
          (1.06,.18,.35),(1.10,.09,.39)]
    samples=16
    verts=[(w*t,y,z+(.16 if y<-.32 else .065)*t*t)
           for y,w,z in rows for t in [i*2/samples-1 for i in range(samples+1)]]
    faces=[(j*17+i,j*17+i+1,(j+1)*17+i+1,(j+1)*17+i)
           for j in range(len(rows)-1) for i in range(samples)]
    shell=mesh("Curved shoehorn shell",verts,faces,mat,True)
    shell.modifiers.new("Pressed steel thickness","SOLIDIFY").thickness=.045
    cut(shell,disk("Hanging hole cutter",(0,.92,.28),.071,.6,mat))
    tube("Ink contour worn spoon edge",[(-.29,-1.01,.174),(-.35,-.88,.127),
         (-.33,-.78,.107)],.004,mat)

def domino(mat):
    tile=solid("Worn domino face",[(-1.03,-.46),(.93,-.46),(1.02,-.40),(1.02,.39),
               (.91,.46),(-.94,.46),(-1.04,.36),(-1.05,-.38)],.245,mat,.043)
    for x,y in [(-.73,-.23),(-.73,.23),(-.49,0),(-.25,-.23),(-.25,.23),(.50,0)]:
        cut(tile,disk("Pip recess cutter",(x,y,.132),.067,.10,mat))
        ring("Ink contour drilled pip",(x,y,.103),.058,.005,mat)
    cut(tile,box("Divider groove cutter",(0,0,.135),(.036,.93,.072),mat,.007))
    tube("Ink contour tile divider",[(0,-.405,.102),(0,.405,.102)],.005,mat)

def bottlecap(mat):
    segments=126
    rings=[(.62,.13,0),(.67,.112,.012),(.69,.045,.036),(.72,-.115,.063)]
    verts=[((r+w*math.cos(i*math.tau/6))*math.cos(i*math.tau/segments),
            (r+w*math.cos(i*math.tau/6))*math.sin(i*math.tau/segments),
            z + (.045*max(0,math.cos(i*math.tau/segments-.4))**6 if j==3 else 0))
           for j,(r,z,w) in enumerate(rings) for i in range(segments)]
    faces=[tuple(range(segments))]
    faces.extend((j*segments+i,(j+1)*segments+i,(j+1)*segments+(i+1)%segments,j*segments+(i+1)%segments)
                 for j in range(len(rings)-1) for i in range(segments))
    cap=mesh("Crimped bottle cap crown",verts,faces,mat,True)
    cap.modifiers.new("Stamped metal thickness","SOLIDIFY").thickness=.034
    disk("Cork sealing liner",(0,0,.062),.59,.065,mat)
    tube("Ink contour rubbed crown",[(.17,.26,.132),(.24,.21,.133),(.28,.13,.133)],.006,mat)

def teaball(mat):
    n=48
    rings=[(.001,-.59),(.28,-.53),(.49,-.34),(.56,-.12),(.57,-.025),
           (.57,.025),(.56,.12),(.49,.34),(.28,.53),(.001,.59)]
    vertices=[(r*math.cos(i*math.tau/n),r*math.sin(i*math.tau/n),z)
              for r,z in rings for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(rings)-1) for i in range(n)
           if not (j in (1,2,6,7) and (i+2*j)%8 in (0,1))]
    shell=mesh("Perforated tea ball shell",vertices,faces,mat,True)
    shell.modifiers.new("Perforated sheet thickness","SOLIDIFY").thickness=.026
    for z in (-.026,.026):
        ring("Tea ball seam",(0,0,z),.566,.023,mat)
    box("Tea ball latch",(.57,0,0),(.14,.16,.14),mat,.026)
    for i in range(7):
        link=ring("Tea ball chain link",(-.021*i,-.018*i,.61+.086*i),.047,.011,mat)
        link.rotation_euler.x=math.pi/2
        link.rotation_euler.z=i*math.pi/2
    end=ring("Chain terminal ring",(-.15,-.13,1.23),.09,.015,mat)
    end.rotation_euler.x=math.pi/2

def shuttle(mat):
    hull=solid("Polished wooden shuttle hull",[(-1.29,-.015),(-.96,-.235),(-.58,-.34),
        (.57,-.35),(.96,-.23),(1.27,.03),(.96,.236),(.61,.35),(-.6,.34),(-.98,.21)],.30,mat,.042)
    cut(hull,box("Shuttle mortise cutter",(0,0,0),(1.35,.39,.55),mat,.105))
    bobbin=disk("Wound shuttle bobbin",(0,0,0),.131,1.05,mat)
    bobbin.rotation_euler.y=math.pi/2
    for x in (-.50,.50):
        rim=ring("Bobbin cheek",(x,0,0),.125,.022,mat)
        rim.rotation_euler.y=math.pi/2
    tube("Shuttle loose thread",[(.16,-.13,.02),(.25,-.26,.166),(.45,-.37,.18),
         (.68,-.43,.165),(.78,-.49,.111)],.011,mat)
    tube("Ink contour shuttle grain",[(-.79,.245,.146),(-.55,.282,.153),(-.29,.274,.153)],.004,mat)

def doorstop(mat):
    wedge=solid("Scuffed rubber door wedge",[(-1.13,-.19),(.99,-.19),(1.08,-.12),
          (1.07,.33),(.93,.38),(-.98,-.078),(-1.14,-.116)],.73,mat,.034)
    wedge.rotation_euler.x=math.pi/2
    for i in range(8):
        x=-.65+i*.197
        z=-.078+(x+.98)*.24
        tube("Rubber grip rib",[(x,-.33,z),(x,0,z+.016),(x,.33,z)],.028,mat)
    tube("Ink contour chipped wedge tip",[(-1.10,-.18,-.10),(-1.01,-.15,-.071),
         (-.94,-.11,-.065)],.005,mat)

def harmonica(mat):
    outline=[(-1.2,-.29),(-1.1,-.39),(1.1,-.39),(1.2,-.29),
             (1.2,.29),(1.08,.39),(-1.08,.39),(-1.2,.29)]
    solid("Rounded harmonica cover",outline,.145,mat,.062).location.z=.158
    solid("Harmonica lower cover",outline,.145,mat,.058).location.z=-.158
    box("Wooden comb backbone",(0,.216,0),(2.26,.28,.19),mat,.028)
    for i in range(11):
        x=-1.11+i*.222
        box("Mouthpiece comb divider",(x,-.105,0),(.065,.49,.19),mat,.018)
    box("Reed plate seam",(0,-.11,0),(2.26,.46,.026),mat,.012)
    for x in (-.99,.99):
        disk("Recessed cover screw",(x,.025,.233),.046,.019,mat)
        tube("Ink contour screw slot",[(x-.027,.025,.244),(x+.027,.025,.244)],.004,mat)
    tube("Ink contour cover dent",[(.56,.27,.231),(.67,.247,.234),(.78,.245,.231)],.005,mat)

def curtainring(mat):
    tube("Worn brass curtain ring",[(.67*math.cos(i*math.tau/100),
         .72*math.sin(i*math.tau/100),.017*math.sin(i*.17)) for i in range(101)],.063,mat)
    disk("Curtain eye base",(0,-.744,0),.12,.14,mat)
    ring("Curtain hook eye",(0,-.892,0),.119,.035,mat)
    tube("Ink contour rubbed ring",[(.46,.522,.047),(.41,.568,.050),(.36,.601,.052)],.004,mat)

def dater(mat):
    handle=disk("Turned date stamp handle",(0,0,.58),.317,.49,mat)
    ring("Handle ferrule",(0,0,.37),.212,.034,mat)
    disk("Stamp stem",(0,0,.24),.124,.38,mat)
    box("Rounded date stamp yoke",(0,0,-.015),(1.14,.57,.17),mat,.045)
    for x in (-.54,.54):
        box("Date stamp side cheek",(x,0,-.23),(.09,.53,.44),mat,.030)
    for x in (-.33,-.11,.11,.33):
        wheel=disk("Date adjustment wheel",(x,0,-.23),.181,.127,mat)
        wheel.rotation_euler.y=math.pi/2
        band=box("Raised rubber date band",(x,0,-.42),(.187,.38,.17),mat,.048)
        for y in (-.102,0,.102):
            box("Raised rubber date mark",(x,y,-.509),(.086,.025,.018),mat,.008)

models={"harmonica":harmonica,"curtainring":curtainring,"dater":dater,"teaball":teaball,"shuttle":shuttle,"doorstop":doorstop,"shoehorn":shoehorn,"domino":domino,"bottlecap":bottlecap,"clothespin":clothespin,"pencap":pencap,"safetypin":safetypin,"key":key,"film":film,"spoon":spoon,"comb":comb,"button":button,"postcard":postcard,
        "spool":spool,"whistle":whistle,"coin":coin,
        "glasses":glasses,"mitten":mitten,"bell":bell,
        "thimble":thimble,"watch":watch,"matchbox":matchbox,
        "luggage":luggage,"earbuds":earbuds,"pencil":pencil,
        "mirror":mirror,"bookmark":bookmark,"envelope":envelope,
        "ticket":ticket,"notebook":notebook,"umbrella":umbrella,"tape":tape,"stamp":stamp,"eraser":eraser}
names=sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else models
for name in names:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version=0
    models[name](material("Paper white",(.89,.89,.89)))
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/"models"/f"{name}.blend"))
    bpy.ops.export_scene.gltf(filepath=str(ROOT/"docs"/"assets"/f"{name}.glb"),export_format="GLB")




