"""Rebuild the three objects used in the first branching route."""
import bpy
import math
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from build import ROOT, box, disk, finish, material, ring

def mesh(name, vertices, faces, mat, smooth=False):
    data = bpy.data.meshes.new(name)
    data.from_pydata(vertices, [], faces)
    data.update()
    obj = bpy.data.objects.new(name,data)
    bpy.context.collection.objects.link(obj)
    finish(obj,name,mat)
    for face in data.polygons:
        face.use_smooth = smooth
    return obj

def solid(name, points, depth, mat, bevel):
    n = len(points)
    vertices = [(x,y,z) for z in (-depth/2,depth/2) for x,y in points]
    faces = [tuple(reversed(range(n))),tuple(range(n,2*n))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    obj = mesh(name,vertices,faces,mat)
    mod = obj.modifiers.new("Softened edge","BEVEL")
    mod.width = bevel
    mod.segments = 3
    obj.modifiers.new("Weighted normals","WEIGHTED_NORMAL")
    return obj

def key(mat):
    pts = [(-.45,.19),(-.58,.32),(-.83,.39),(-1.06,.34),(-1.19,.19),(-1.24,-.08),(-1.12,-.29),(-.89,-.39),(-.64,-.35),(-.47,-.24),(-.32,-.24),(-.25,-.17),(-.04,-.17),(.06,-.24),(.15,-.24),(.22,-.12),(.32,-.12),(.42,-.26),(.5,-.26),(.61,-.15),(.68,-.15),(.78,-.22),(.85,-.22),(.93,-.13),(1.05,-.13),(1.24,.01),(1.13,.15),(-.28,.15),(-.32,.2)]
    blank = solid("Stamped brass silhouette",pts,.115,mat,.016)
    bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.145,depth=1,location=(-.94,.025,0))
    cutter = bpy.context.object
    bpy.context.view_layer.objects.active = blank
    boolean = blank.modifiers.new("Keyring hole","BOOLEAN")
    boolean.object = cutter
    bpy.ops.object.modifier_move_up(modifier=boolean.name)
    bpy.ops.object.modifier_move_up(modifier=boolean.name)
    bpy.ops.object.modifier_apply(modifier=boolean.name)
    bpy.data.objects.remove(cutter,do_unlink=True)
    for y,w in [(0.064,1.12),(-.036,1.04)]:
        box("Blade milling line",(.51,y,.058),(w,.018,.008),mat,.004)
    for x,angle in [(-.55,-.16),(-.43,-.14),(-.32,-.11)]:
        wrap=box("Overlapping cloth tape",(x,-.015,.014),(.17,.45,.142),mat,.029)
        wrap.rotation_euler.z=angle
    tab=box("Lifted tape corner",(-.28,.173,.104),(.11,.12,.018),mat,.007)
    tab.rotation_euler.x=.43

def spoon(mat):
    count=64
    vertices=[(.67,0,-.11)]
    for radius in (.15,.3,.48,.65,.82,1):
        for i in range(count):
            a=i*math.tau/count
            vertices.append((.67+.59*radius*math.cos(a),.43*radius*math.sin(a),-.11+.24*radius**2))
    faces=[(0,1+i,1+(i+1)%count) for i in range(count)]
    for row in range(5):
        a=1+row*count
        b=a+count
        faces += [(a+i,b+i,b+(i+1)%count,a+(i+1)%count) for i in range(count)]
    bowl=mesh("Pressed concave bowl",vertices,faces,mat,True)
    bowl.modifiers.new("Rolled metal thickness","SOLIDIFY").thickness=.035
    curve=bpy.data.curves.new("Bowl rim contour","CURVE")
    curve.dimensions="3D"
    curve.bevel_depth=.0037
    curve.bevel_resolution=2
    spline=curve.splines.new("POLY")
    spline.points.add(23)
    for i,point in enumerate(spline.points):
        angle=-1.2+2.45*i/23
        r=.79+.09*math.sin(math.pi*i/23)
        point.co=(.67+.59*r*math.cos(angle),.43*r*math.sin(angle),-.11+.24*r*r+.006,1)
    mark=bpy.data.objects.new("Ink contour inside bowl",curve)
    bpy.context.collection.objects.link(mark)
    curve.materials.append(mat)
    handle=solid("Tapered handle",[(-1.48,-.03),(-1.46,-.1),(-1.37,-.15),(-1.14,-.148),(-.68,-.094),(-.28,-.051),(.18,-.043),(.24,0),(.18,.043),(-.28,.051),(-.68,.094),(-1.14,.148),(-1.37,.15),(-1.46,.1),(-1.48,.03)],.07,mat,.027)
    handle.location.z=.1

def film(mat):
    disk("Crimped metal cartridge",(-.52,0,0),.465,1.29,mat)
    for z in [-.65,.65]:
        disk("Rolled end seam",(-.52,0,z),.487,.081,mat)
        ring("Stamped end rim",(-.52,0,z+math.copysign(.041,z)),.41,.019,mat)
    disk("Recessed spool hub",(-.52,0,.739),.172,.14,mat)
    box("Spool notch",(-.52,-.148,.771),(.12,.072,.075),mat,.012)
    box("Light-trap lip",(-.11,-.17,0),(.21,.16,1.16),mat,.049)
    # One bent strip. Omitted cells form actual holes along both edges.
    rows=(-.49,-.44,-.36,.36,.44,.49)
    length=26
    vertices=[]
    for i in range(length+1):
        t=i/length
        for z in rows:
            taper=.64+.36*(1-min(1,max(0,(t-.72)/.28)))
            vertices.append((-.07+1.58*t,-.25+.31*math.sin(t*2.7),z*taper))
    faces=[]
    for i in range(length):
        for j in range(5):
            if j in (1,3) and i%2==1:
                continue
            k=i*6+j
            faces.append((k,k+1,k+7,k+6))
    strip=mesh("Curled perforated film leader",vertices,faces,mat,True)
    strip.modifiers.new("Film thickness","SOLIDIFY").thickness=.011

def comb(mat):
    edge=[(-1.24,-.04)]
    for i in range(15):
        x=-1.18+i*.162
        if i==4:
            edge.extend([(x,-.045),(x+.04,-.12),(x+.085,-.075),(x+.118,-.045)])
            continue
        tip=-.61+.125*(x/1.2)**2
        edge.extend([(x,-.045),(x+.023,tip+.035),(x+.047,tip),
                     (x+.067,tip+.024),(x+.114,-.045)])
    edge.extend([(1.22,-.035),(1.25,.04),(1.22,.18),(1.14,.23),(.55,.28),
                 (-.4,.29),(-1.05,.25),(-1.21,.19),(-1.26,.08)])
    solid("Rounded pocket comb with broken fifth tooth",edge,.115,mat,.021)

def button(mat):
    profile=[(.001,-.095),(.54,-.095),(.66,-.078),(.704,-.042),
             (.712,.016),(.686,.084),(.632,.115),(.581,.113),(.51,.074),
             (.43,.038),(.29,.026),(.001,.025)]
    n=96
    vertices=[(r*math.cos(i*math.tau/n),r*math.sin(i*math.tau/n),z)
              for r,z in profile for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces.extend([tuple(reversed(range(n))),tuple(range((len(profile)-1)*n,len(profile)*n))])
    obj=mesh("Recessed four-hole button",vertices,faces,mat,True)
    for x in (-.154,.154):
        for y in (-.154,.154):
            bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.078,depth=.6,location=(x,y,0))
            cutter=bpy.context.object
            bpy.context.view_layer.objects.active=obj
            mod=obj.modifiers.new("Thread bore","BOOLEAN")
            mod.object=cutter
            bpy.ops.object.modifier_apply(modifier=mod.name)
            bpy.data.objects.remove(cutter,do_unlink=True)
    bevel=obj.modifiers.new("Soft bore rims","BEVEL")
    bevel.width=.008
    bevel.segments=2

def postcard(mat):
    def z(x,y):
        fold=max(0,(x+y-1.34)/.49)
        return .018*x*x-.026*y*y+.21*fold*fold
    nx,ny=26,16
    vertices=[(x,y,z(x,y)) for j in range(ny+1) for i in range(nx+1)
              for x,y in [(-1.2+2.4*i/nx,-.74+1.48*j/ny)]]
    faces=[(k,k+1,k+nx+2,k+nx+1) for j in range(ny) for i in range(nx)
           for k in [j*(nx+1)+i]]
    card=mesh("Warped postcard paper with lifted corner",vertices,faces,mat,True)
    card.modifiers.new("Paper edge","SOLIDIFY").thickness=.025
    ink=material("Graphite print",(.22,.23,.21))
    def stroke(name, points, side=1):
        curve=bpy.data.curves.new(name,"CURVE")
        curve.dimensions="3D"
        curve.bevel_depth=.004
        curve.bevel_resolution=2
        spline=curve.splines.new("POLY")
        spline.points.add(len(points)-1)
        for point,(x,y) in zip(spline.points,points):
            point.co=(x,y,z(x,y)+(.005 if side==1 else -.031),1)
        obj=bpy.data.objects.new("Ink contour "+name,curve)
        bpy.context.collection.objects.link(obj)
        curve.materials.append(ink)
    stroke("coastal ridge",[(-1.02,-.18),(-.78,-.12),(-.59,.04),(-.48,-.015),(-.31,.15),(-.12,.075),(.04,-.14),(.31,-.24),(.53,-.22),(1.02,-.14)])
    for j in range(3):
        y=-.32-j*.095
        stroke("water line",[(-.89+j*.27,y),(-.52+j*.24,y+.024),(-.22+j*.28,y-.008),(.23+j*.17,y+.014)])
    stroke("sun",[(.49+.143*math.cos(i*math.tau/48),.28+.143*math.sin(i*math.tau/48)) for i in range(49)])
    for y in (-.23,-.06,.11):
        stroke("address line",[(-.96,y),(-.28,y)],-1)
    stroke("address separator",[(.02,-.49),(.02,.49)],-1)

def tube(name, points, radius, mat):
    curve=bpy.data.curves.new(name,"CURVE")
    curve.dimensions="3D"
    curve.bevel_depth=radius
    curve.bevel_resolution=2
    spline=curve.splines.new("POLY")
    spline.points.add(len(points)-1)
    for point,coords in zip(spline.points,points):
        point.co=(*coords,1)
    obj=bpy.data.objects.new(name,curve)
    bpy.context.collection.objects.link(obj)
    curve.materials.append(mat)
    return obj

def cut(obj,cutter):
    bpy.context.view_layer.objects.active=obj
    mod=obj.modifiers.new("Recess","BOOLEAN")
    mod.object=cutter
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter,do_unlink=True)

def ticket(mat):
    card=solid("Thin card ticket",[(-1.14,-.43),(1.13,-.43),(1.15,-.40),(1.15,.42),
                                  (1.11,.445),(-1.13,.44),(-1.16,.39),(-1.16,-.39)],.032,mat,.008)
    for x,y,length in [(-.92,.27,.93),(-.92,.06,1.28),(-.92,-.13,.64),(-.92,-.28,1.18)]:
        tube("Ink contour printed rule",[(x,y,.018),(x+length,y,.018)],.005,mat)
    for y in [-.33,-.23,-.13,-.03,.07,.17,.27,.37]:
        tube("Ink contour printed divider",[(.61,y,.018),(.61,y+.034,.018)],.004,mat)
    return card

def notebook(mat):
    cover=[(-.79,-1.0),(.7,-1.0),(.77,-.93),(.77,.95),(.71,1.0),(-.76,1.0),(-.86,.92),(-.86,-.92)]
    for z in (-.16,.16):
        solid("Rounded cloth cover",cover,.055,mat,.023).location.z=z
    box("Bound paper block",(-.01,0,0),(1.44,1.89,.28),mat,.064)
    box("Rounded book spine",(-.792,0,0),(.165,1.93,.365),mat,.071)
    for z in [-.087,-.038,.011,.06,.108]:
        tube("Ink contour page edges",[(.707,-.88,z),(.716,0,z+.006),(.708,.88,z)],.003,mat)
    pts=[(.22,-.65,.055),(.35,-.65,.055),(.35,-.96,.047),(.36,-1.08,.03),
         (.37,-1.21,-.015),(.34,-1.34,-.09),(.24,-1.32,-.09),(.25,-1.20,-.014),
         (.24,-1.08,.028),(.22,-.96,.046)]
    ribbon=mesh("Curving ribbon bookmark",pts,[tuple(reversed(range(len(pts))))],mat)
    ribbon.modifiers.new("Ribbon thickness","SOLIDIFY").thickness=.012

def umbrella(mat):
    n=48
    profile=[(-.91,.105),(-.72,.20),(-.4,.175),(-.07,.139),(.2,.154),(.62,.105),(.93,.033)]
    vertices=[]
    for j,(x,r) in enumerate(profile):
        for i in range(n):
            a=i*math.tau/n
            wave=r*(1+.18*math.cos(6*a+j*.30))
            vertices.append((x,wave*math.cos(a),wave*math.sin(a)))
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces += [tuple(reversed(range(n))),tuple(range((len(profile)-1)*n,len(profile)*n))]
    mesh("Pleated folded umbrella canopy",vertices,faces,mat,True)
    for i in (0,16,32):
        tube("Ink contour folded seam",[vertices[j*n+(i+j//2)%n] for j in range(len(profile))],.006,mat)
    tube("Hook handle",[(-.88,0,0),(-1.12,0,0)]+[(-1.12+.16*math.cos(a),.16+.16*math.sin(a),0)
         for a in [-math.pi/2-i*.16 for i in range(25)]],.059,mat)
    tube("Metal tip",[(.88,0,0),(1.15,0,0)],.029,mat)
    strap=mesh("Loose retaining strap",[(-.24,-.15,.05),(-.09,-.15,.05),(-.04,-.21,.13),
               (.11,-.3,.205),(-.01,-.34,.218),(-.19,-.215,.13)],[(0,1,2,3,4,5)],mat)
    strap.modifiers.new("Strap cloth","SOLIDIFY").thickness=.016

def tape(mat):
    shell=box("Cassette shell",(0,0,0),(2.16,1.38,.205),mat,.055)
    for x in (-.48,.48):
        cut(shell,disk("Spool bore cutter",(x,.10,0),.172,.65,mat))
        ring("Recessed hub",(x,.1,.015),.118,.024,mat)
        for i in range(6):
            a=i*math.tau/6
            ring_tooth=box("Hub tooth",(x+.108*math.cos(a),.1+.108*math.sin(a),.015),(.039,.025,.07),mat,.006)
            ring_tooth.rotation_euler.z=a
    cut(shell,box("Tape gate cutter",(0,-.56,.01),(1.23,.31,.19),mat,.035))
    tube("Ink contour seam",[(-1.03,-.67,0),(1.03,-.67,0),(1.08,-.61,0),(1.08,.62,0),
         (1.02,.69,0),(-1.02,.69,0),(-1.08,.62,0),(-1.08,-.61,0),(-1.03,-.67,0)],.005,mat)
    for x in (-.94,.94):
        for y in (-.52,.54):
            ring("Shell screw rim",(x,y,.102),.033,.008,mat)
    for y in (.44,.52):
        tube("Ink contour label line",[(-.75,y,.104),(.67,y,.104)],.004,mat)

def stamp(mat):
    shape=[(-.76,-.42),(.71,-.42),(.77,-.36),(.77,.36),(.71,.42),(-.7,.42),(-.76,.35)]
    solid("Wooden block",shape,.27,mat,.054)
    box("Wooden grip",(-.02,0,-.19),(1.28,.66,.18),mat,.079)
    face=box("Rubber printing face",(0,0,.181),(1.36,.71,.13),mat,.032)
    for x,angle in [(-.32,0),(-.045,.13),(.23,-.45)]:
        cutter=box("Carving cutter",(x,.015,.245),(.042,.48,.105),mat,.008)
        cutter.rotation_euler.z=angle
        cut(face,cutter)

def eraser(mat):
    solid("Worn rubber body",[(-.91,-.25),(-.78,-.36),(.75,-.37),(.85,-.31),(.86,.30),
                             (.79,.36),(-.75,.36),(-.87,.26),(-.93,.08)],.31,mat,.082)
    cross=[(-.373,.11),(-.34,.164),(.33,.164),(.374,.112),(.374,-.11),
           (.33,-.164),(-.33,-.164),(-.373,-.11)]
    vertices=[(x,y,z) for x in (-.09,.59) for y,z in cross]
    faces=[(i,(i+1)%8,(i+1)%8+8,i+8) for i in range(8)]
    sleeve=mesh("Thin folded paper sleeve",vertices,faces,mat)
    sleeve.modifiers.new("Paper thickness","SOLIDIFY").thickness=.012
    flap=mesh("Lifted sleeve corner",[(-.09,.20,.165),(.075,.35,.166),(-.19,.385,.231),(-.24,.27,.198)],[(0,1,2,3)],mat)
    flap.modifiers.new("Flap thickness","SOLIDIFY").thickness=.012
    for x in (.17,.24):
        tube("Ink contour sleeve print",[(x,-.30,.172),(x,.29,.172)],.004,mat)

def mirror(mat):
    frame=disk("Oval metal frame",(0,.35,0),.62,.13,mat)
    frame.scale.y=1.22
    glass=disk("Recessed mirror glass",(0,.35,.071),.53,.025,mat)
    glass.scale.y=1.22
    tube("Rolled bezel",[(.582*math.cos(i*math.tau/64),.35+.706*math.sin(i*math.tau/64),.069)
                         for i in range(65)],.027,mat)
    solid("Tapered mirror handle",[(-.18,-1.03),(-.13,-1.14),(0,-1.19),(.13,-1.14),(.18,-1.03),
          (.13,-.68),(.085,-.33),(-.085,-.33),(-.13,-.68)],.112,mat,.03)
    tube("Ink contour worn glass edge",[(.28,-.11,.087),(.32,-.085,.087),(.29,-.025,.087)],.004,mat)

def bookmark(mat):
    outline=[(-.31,-1.13,.02),(.31,-1.14,.023),(.32,-.1,-.041),(.315,.08,-.027),
             (.29,1.13,.112),(-.315,1.11,.10),(-.33,.08,-.025),(-.32,-.1,-.039)]
    paper=mesh("Folded bookmark paper",outline,[(0,1,2,7),(7,2,3,6),(6,3,4,5)],mat)
    paper.modifiers.new("Thin paper","SOLIDIFY").thickness=.021
    tube("Ink contour fold line",[outline[7],(.01,-.1,-.026),outline[2]],.004,mat)
    tube("Ink contour pencilled mark",[(-.08,.43,.037),(-.02,.51,.047),(.09,.46,.041)],.004,mat)

def envelope(mat):
    outline=[(-1.15,-.55),(-1.1,-.62),(1.10,-.61),(1.15,-.54),(1.13,.58),(-1.14,.59)]
    solid("Envelope front paper",outline,.025,mat,.008).location.z=-.028
    back=mesh("Folded envelope back",[(x,y,.023) for x,y in outline]+[(0,-.24,.034)],
              [(0,1,6,5),(1,2,3,6),(6,3,4),(5,6,4)],mat)
    back.modifiers.new("Paper thickness","SOLIDIFY").thickness=.016
    flap=mesh("Torn open flap",[(-1.13,.56,.014),(1.13,.56,.014),(.76,.75,.071),(.51,.85,.11),
              (.31,.9,.13),(.17,.86,.122),(.04,.95,.137),(-.21,.93,.133),(-.58,.81,.089)],
              [(0,1,2,3,4,5,6,7,8)],mat)
    flap.modifiers.new("Flap thickness","SOLIDIFY").thickness=.016
    tube("Ink contour envelope seam",[(-1.12,.49,.035),(0,-.24,.044),(1.11,.49,.035)],.005,mat)

def luggage(mat):
    shape=[(-1.13,-.44),(.80,-.44),(1.01,-.26),(1.01,.26),(.80,.44),(-1.13,.44)]
    body=solid("Leather luggage tag",shape,.12,mat,.045)
    cut(body,disk("Strap hole cutter",(.84,0,0),.078,.48,mat))
    box("Recessed luggage label",(-.31,0,.067),(1.28,.55,.025),mat,.039)
    for y in (-.13,.02,.16):
        tube("Ink contour label rule",[(-.79,y,.082),(.22,y,.082)],.004,mat)
    for y in (-.36,.36):
        for i in range(12):
            x=-.99+i*.145
            tube("Ink contour leather stitch",[(x,y,.062),(x+.056,y,.062)],.004,mat)
    tube("Bent leather strap",[(.83,0,.017),(1.12,-.105,.063),(1.38,-.08,.093),
                              (1.49,.025,.071),(1.37,.12,.019),(1.12,.097,-.035),(.84,0,-.031)],.043,mat)

def earbuds(mat):
    def smooth(name, points, radius):
        curve=bpy.data.curves.new(name,"CURVE")
        curve.dimensions="3D"
        curve.bevel_depth=radius
        curve.bevel_resolution=3
        spline=curve.splines.new("BEZIER")
        spline.bezier_points.add(len(points)-1)
        for point,coords in zip(spline.bezier_points,points):
            point.co=coords
            point.handle_left_type=point.handle_right_type="AUTO"
        obj=bpy.data.objects.new(name,curve)
        bpy.context.collection.objects.link(obj)
        curve.materials.append(mat)
    for i,(x,y) in enumerate([(-.65,.66),(.59,.51)]):
        shell=disk("Earbud housing left" if i==0 else "Earbud housing right",(x,y,.045),.187,.145,mat)
        shell.scale.x=1.11
        ring("Speaker grille rim",(x,y,.122),.119,.014,mat)
        for j in range(5):
            d=-.06+j*.03
            tube("Ink contour grille slot",[(x-.055,y+d,.13),(x+.055,y+d,.13)],.003,mat)
        smooth("Earbud branch lead",[(x,y-.12,0),(x*.83,.19,.015),(x*.53,-.07,.025),(.03,-.32,0)],.017)
    box("Cable junction",(.03,-.32,0),(.105,.17,.086),mat,.039)
    smooth("Loosely looped lead",[(.03,-.36,0),(-.21,-.60,0),(-.62,-.65,0),(-.83,-.43,-.04),
           (-.55,-.22,-.05),(.09,-.59,-.065),(.53,-.8,-.052),(.89,-.68,0)],.019)
    box("Plug grip",(.89,-.60,0),(.13,.23,.105),mat,.033)
    tube("Metal audio jack",[(.89,-.54,0),(.89,-.27,0)],.031,mat)
    for y in (-.38,-.33):
        tube("Ink contour jack divider",[(.86,y,.025),(.92,y,.025)],.004,mat)

def pencil(mat):
    n=6
    profile=[(-1.05,.164),(.51,.164),(.76,.097),(.96,.033),(1.085,.013)]
    vertices=[(x,r*math.cos(math.tau*i/n),r*math.sin(math.tau*i/n))
              for x,r in profile for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces += [tuple(reversed(range(n))),tuple(range((len(profile)-1)*n,len(profile)*n))]
    mesh("Short hexagonal pencil barrel",vertices,faces,mat)
    tube("Ink contour chipped lacquer",[(-.35,-.079,.142),(-.23,-.088,.141),
         (-.17,-.06,.143),(-.02,-.073,.143)],.006,mat)
    tube("Ink contour graphite tip",[(.956,0,.029),(1.028,0,.022),(1.083,0,.012)],.004,mat)

def thimble(mat):
    n=64
    profile=[(.57,-.65),(.57,-.52),(.54,-.42),(.49,.28),(.42,.52),(.29,.63),(.001,.67)]
    vertices=[(r*math.cos(i*math.tau/n),r*math.sin(i*math.tau/n),z)
              for r,z in profile for i in range(n)]
    faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i)
           for j in range(len(profile)-1) for i in range(n)]
    faces.append(tuple(range((len(profile)-1)*n,len(profile)*n)))
    shell=mesh("Hollow tapered thimble",vertices,faces,mat,True)
    shell.modifiers.new("Stamped silver wall","SOLIDIFY").thickness=.038
    ring("Rolled thimble lip",(0,0,-.62),.554,.027,mat)
    for row in range(5):
        z=-.32+row*.14
        r=.534-(z+.32)*.074
        for i in range(15):
            angle=(i+row*.5)*math.tau/15
            tube("Ink contour shallow dimple",[(r*math.cos(angle+d),r*math.sin(angle+d),z+h)
                 for d,h in [(-.032,.016),(0,-.014),(.032,.016)]],.004,mat)

def watch(mat):
    for side in (-1,1):
        end=side*1.12
        strap=solid("Curved leather watch strap",[(-.23,side*.36),(.23,side*.36),
                    (.19,end),(.10,end+side*.09),(-.11,end+side*.08),(-.18,end)],.083,mat,.021)
        if side<0:
            for i in range(4):
                y=-.65-i*.12
                cut(strap,disk("Buckle hole cutter",(0,y,0),.034,.35,mat))
    disk("Watch case",(0,0,0),.49,.19,mat)
    disk("Stopped watch dial",(0,0,.105),.415,.035,mat)
    ring("Watch bezel",(0,0,.102),.449,.033,mat)
    box("Winding crown",(.495,0,.005),(.14,.126,.125),mat,.035)
    for i in range(12):
        a=i*math.tau/12
        tube("Ink contour dial mark",[(.34*math.cos(a),.34*math.sin(a),.128),
             (.38*math.cos(a),.38*math.sin(a),.128)],.005,mat)
    for angle,length in [(-1.72,.21),(-.315,.30)]:
        tube("Ink contour stopped hand",[(0,0,.133),(length*math.cos(angle),length*math.sin(angle),.133)],.011,mat)

def matchbox(mat):
    sleeve=box("Printed matchbox sleeve",(-.27,0,0),(1.57,.88,.44),mat,.032)
    cut(sleeve,box("Drawer recess cutter",(-.27,0,0),(2,.746,.34),mat,.013))
    box("Sliding tray bottom",(.37,0,-.155),(1.54,.70,.045),mat,.022)
    for y in (-.335,.335):
        box("Thin folded tray wall",(.36,y,-.032),(1.53,.042,.24),mat,.014)
    box("Exposed tray end",(1.12,0,-.032),(.045,.702,.24),mat,.013)
    for i,(y,tip) in enumerate([(-.19,.92),(-.045,1.02),(.137,.87)]):
        tube("Wooden match splint",[(.16,y,-.08),(tip-.08,y+.02,-.076)],.025,mat)
        tip_obj=disk("Rounded match head",(tip-.066,y+.02,-.076),.046,.061,mat)
        tip_obj.scale.x=1.37
    for y in (-.27,-.19,.17,.25):
        tube("Ink contour label ornament",[(-.88,y,.223),(.29,y,.223)],.004,mat)

models={"key":key,"film":film,"spoon":spoon,"comb":comb,"button":button,"postcard":postcard,
        "thimble":thimble,"watch":watch,"matchbox":matchbox,
        "luggage":luggage,"earbuds":earbuds,"pencil":pencil,
        "mirror":mirror,"bookmark":bookmark,"envelope":envelope,
        "ticket":ticket,"notebook":notebook,"umbrella":umbrella,"tape":tape,"stamp":stamp,"eraser":eraser}
names=sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else models
for name in names:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version=0
    models[name](material("Paper white",(.89,.89,.89)))
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/"models"/f"{name}.blend"))
    bpy.ops.export_scene.gltf(filepath=str(ROOT/"docs"/"assets"/f"{name}.glb"),export_format="GLB")
