"""Rebuild the three objects used in the first branching route."""
import bpy
import math
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from build import ROOT, box, disk, finish, material, ring

def mesh(name, vertices, faces, mat, smooth=False):
    data = bpy.data.meshes.new(name)
    data.from_pydata(vertices, [], faces)
    data.update()
    obj = bpy.data.objects.new(name,data)
    bpy.context.collection.objects.link(obj)
    finish(obj,name,mat)
    for face in data.polygons:
        face.use_smooth = smooth
    return obj

def solid(name, points, depth, mat, bevel):
    n = len(points)
    vertices = [(x,y,z) for z in (-depth/2,depth/2) for x,y in points]
    faces = [tuple(reversed(range(n))),tuple(range(n,2*n))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    obj = mesh(name,vertices,faces,mat)
    mod = obj.modifiers.new("Softened edge","BEVEL")
    mod.width = bevel
    mod.segments = 3
    obj.modifiers.new("Weighted normals","WEIGHTED_NORMAL")
    return obj

def key(mat):
    pts = [(-.45,.19),(-.58,.32),(-.83,.39),(-1.06,.34),(-1.19,.19),(-1.24,-.08),(-1.12,-.29),(-.89,-.39),(-.64,-.35),(-.47,-.24),(-.32,-.24),(-.25,-.17),(-.04,-.17),(.06,-.24),(.15,-.24),(.22,-.12),(.32,-.12),(.42,-.26),(.5,-.26),(.61,-.15),(.68,-.15),(.78,-.22),(.85,-.22),(.93,-.13),(1.05,-.13),(1.24,.01),(1.13,.15),(-.28,.15),(-.32,.2)]
    blank = solid("Stamped brass silhouette",pts,.115,mat,.016)
    bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.145,depth=1,location=(-.94,.025,0))
    cutter = bpy.context.object
    bpy.context.view_layer.objects.active = blank
    boolean = blank.modifiers.new("Keyring hole","BOOLEAN")
    boolean.object = cutter
    bpy.ops.object.modifier_move_up(modifier=boolean.name)
    bpy.ops.object.modifier_move_up(modifier=boolean.name)
    bpy.ops.object.modifier_apply(modifier=boolean.name)
    bpy.data.objects.remove(cutter,do_unlink=True)
    for y,w in [(0.064,1.12),(-.036,1.04)]:
        box("Blade milling line",(.51,y,.058),(w,.018,.008),mat,.004)
    for x,angle in [(-.55,-.16),(-.43,-.14),(-.32,-.11)]:
        wrap=box("Overlapping cloth tape",(x,-.015,.014),(.17,.45,.142),mat,.029)
        wrap.rotation_euler.z=angle
    tab=box("Lifted tape corner",(-.28,.173,.104),(.11,.12,.018),mat,.007)
    tab.rotation_euler.x=.43

def spoon(mat):
    count=64
    vertices=[(.67,0,-.11)]
    for radius in (.15,.3,.48,.65,.82,1):
        for i in range(count):
            a=i*math.tau/count
            vertices.append((.67+.59*radius*math.cos(a),.43*radius*math.sin(a),-.11+.24*radius**2))
    faces=[(0,1+i,1+(i+1)%count) for i in range(count)]
    for row in range(5):
        a=1+row*count
        b=a+count
        faces += [(a+i,b+i,b+(i+1)%count,a+(i+1)%count) for i in range(count)]
    bowl=mesh("Pressed concave bowl",vertices,faces,mat,True)
    bowl.modifiers.new("Rolled metal thickness","SOLIDIFY").thickness=.035
    curve=bpy.data.curves.new("Bowl rim contour","CURVE")
    curve.dimensions="3D"
    curve.bevel_depth=.0037
    curve.bevel_resolution=2
    spline=curve.splines.new("POLY")
    spline.points.add(23)
    for i,point in enumerate(spline.points):
        angle=-1.2+2.45*i/23
        r=.79+.09*math.sin(math.pi*i/23)
        point.co=(.67+.59*r*math.cos(angle),.43*r*math.sin(angle),-.11+.24*r*r+.006,1)
    mark=bpy.data.objects.new("Ink contour inside bowl",curve)
    bpy.context.collection.objects.link(mark)
    curve.materials.append(mat)
    handle=solid("Tapered handle",[(-1.48,-.03),(-1.46,-.1),(-1.37,-.15),(-1.14,-.148),(-.68,-.094),(-.28,-.051),(.18,-.043),(.24,0),(.18,.043),(-.28,.051),(-.68,.094),(-1.14,.148),(-1.37,.15),(-1.46,.1),(-1.48,.03)],.07,mat,.027)
    handle.location.z=.1

def film(mat):
    disk("Crimped metal cartridge",(-.52,0,0),.465,1.29,mat)
    for z in [-.65,.65]:
        disk("Rolled end seam",(-.52,0,z),.487,.081,mat)
        ring("Stamped end rim",(-.52,0,z+math.copysign(.041,z)),.41,.019,mat)
    disk("Recessed spool hub",(-.52,0,.739),.172,.14,mat)
    box("Spool notch",(-.52,-.148,.771),(.12,.072,.075),mat,.012)
    box("Light-trap lip",(-.11,-.17,0),(.21,.16,1.16),mat,.049)
    # One bent strip. Omitted cells form actual holes along both edges.
    rows=(-.49,-.44,-.36,.36,.44,.49)
    length=26
    vertices=[]
    for i in range(length+1):
        t=i/length
        for z in rows:
            taper=.64+.36*(1-min(1,max(0,(t-.72)/.28)))
            vertices.append((-.07+1.58*t,-.25+.31*math.sin(t*2.7),z*taper))
    faces=[]
    for i in range(length):
        for j in range(5):
            if j in (1,3) and i%2==1:
                continue
            k=i*6+j
            faces.append((k,k+1,k+7,k+6))
    strip=mesh("Curled perforated film leader",vertices,faces,mat,True)
    strip.modifiers.new("Film thickness","SOLIDIFY").thickness=.011

for name,build in [("key",key),("film",film),("spoon",spoon)]:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version=0
    build(material("Paper white",(.89,.89,.89)))
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/"models"/f"{name}.blend"))
    bpy.ops.export_scene.gltf(filepath=str(ROOT/"docs"/"assets"/f"{name}.glb"),export_format="GLB")
